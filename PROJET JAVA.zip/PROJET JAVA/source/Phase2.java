public class Phase2 implements phase{
    @Override
    public void sélectionDesJoueurs() {

    }

    @Override
    public void DéroulerUnePhase() {

    }
}
