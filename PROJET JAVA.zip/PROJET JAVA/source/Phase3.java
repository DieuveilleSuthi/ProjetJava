public class Phase3 implements phase{
    @Override
    public void sélectionDesJoueurs() {
        
    }

    @Override
    public void DéroulerUnePhase() {

    }
}
