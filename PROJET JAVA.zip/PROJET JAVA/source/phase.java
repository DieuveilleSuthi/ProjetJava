public interface phase
{
    void sélectionDesJoueurs();

    void DéroulerUnePhase();
}
